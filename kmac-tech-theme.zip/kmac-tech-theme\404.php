<?php
/**
 * KMAC Tech — 404 Not Found Template
 */
get_header(); ?>

<main id="main-content">
  <section style="text-align:center;padding:120px 24px 80px;">
    <div class="container">
      <div style="font-size:6rem;margin-bottom:24px;">🔍</div>
      <h1 style="font-size:3rem;margin-bottom:12px;">404</h1>
      <h2 style="font-size:1.4rem;font-weight:500;color:var(--text-sec);margin-bottom:32px;">
        <?php echo kmac_t("Oops! This page doesn't exist.", 'Trang này không tồn tại!'); ?>
      </h2>
      <p style="color:var(--text-sec);margin-bottom:40px;max-width:480px;margin-left:auto;margin-right:auto;">
        <?php echo kmac_t(
          "The page you're looking for might have been moved or doesn't exist. Let's get you back on track!",
          'Trang bạn tìm kiếm có thể đã bị di chuyển hoặc không còn tồn tại.'
        ); ?>
      </p>
      <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary btn-lg">
          ← <?php echo kmac_t('Back to Home', 'Về trang chủ'); ?>
        </a>
        <a href="<?php echo esc_url(get_permalink(wc_get_page_id('shop'))); ?>" class="btn btn-secondary btn-lg">
          <?php echo kmac_t('Browse Shop', 'Xem cửa hàng'); ?>
        </a>
      </div>
    </div>
  </section>

  <!-- Popular Products -->
  <?php if ( function_exists('woocommerce_output_related_products') ) : ?>
    <section class="section" style="background:var(--blue-light);">
      <div class="container">
        <h2 class="section-title"><?php echo kmac_t('Popular Products ⭐', 'Sản phẩm phổ biến ⭐'); ?></h2>
        <p class="section-subtitle"><?php echo kmac_t('While you\'re here, check out our bestsellers', 'Khám phá sản phẩm bán chạy nhất'); ?></p>
        <?php
        $args = array('post_type' => 'product', 'posts_per_page' => 4, 'meta_key' => 'total_sales', 'orderby' => 'meta_value_num');
        $products = new WP_Query($args);
        if ( $products->have_posts() ) {
            echo '<div class="grid grid-4" style="margin-top:32px;">';
            while ( $products->have_posts() ) {
                $products->the_post();
                wc_get_template_part('content', 'product');
            }
            echo '</div>';
            wp_reset_postdata();
        }
        ?>
      </div>
    </section>
  <?php endif; ?>
</main>

<?php get_footer(); ?>
