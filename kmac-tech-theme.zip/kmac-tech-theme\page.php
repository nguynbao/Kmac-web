<?php
/**
 * KMAC Tech — Static Page Template
 */
get_header(); ?>

<main id="main-content">
  <?php while ( have_posts() ) : the_post(); ?>
    <section class="section">
      <div class="container">
        <h1 style="font-size:2rem;margin-bottom:32px;"><?php the_title(); ?></h1>
        <div class="entry-content" style="max-width:820px;color:var(--text-sec);line-height:1.8;">
          <?php the_content(); ?>
        </div>
      </div>
    </section>
  <?php endwhile; ?>
</main>

<?php get_footer(); ?>
