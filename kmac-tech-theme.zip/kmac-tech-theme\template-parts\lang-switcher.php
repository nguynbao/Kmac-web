<?php
/**
 * KMAC Tech — Language Switcher Component
 *
 * Usage: get_template_part('template-parts/lang-switcher');
 * Renders a pill-shaped EN/VN toggle in the header.
 */
$current_lang = kmac_get_lang();
?>
<div class="lang-switcher" id="langSwitcher" aria-label="<?php echo kmac_t('Language Switcher', 'Chuyển đổi ngôn ngữ'); ?>">
  <a href="<?php echo esc_url(add_query_arg('lang', 'en')); ?>"
     class="lang-btn <?php echo $current_lang === 'en' ? 'active' : ''; ?>"
     aria-label="Switch to English"
     <?php echo $current_lang === 'en' ? 'aria-current="true"' : ''; ?>>🇺🇸 EN</a>
  <a href="<?php echo esc_url(add_query_arg('lang', 'vn')); ?>"
     class="lang-btn <?php echo $current_lang === 'vn' ? 'active' : ''; ?>"
     aria-label="Chuyển sang Tiếng Việt"
     <?php echo $current_lang === 'vn' ? 'aria-current="true"' : ''; ?>>🇻🇳 VN</a>
</div>
