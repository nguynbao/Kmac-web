<?php
/**
 * KMAC Tech — Main Index Template (Fallback)
 *
 * WordPress template hierarchy fallback.
 * For the homepage, WordPress uses front-page.php instead.
 * For blog archives, WordPress uses archive.php instead.
 * This file catches anything that doesn't match a more specific template.
 *
 * @package KMACTech
 * @version 1.0
 */

get_header(); ?>

<main id="main-content">

  <?php if ( have_posts() ) : ?>
    <section class="section">
      <div class="container">
        <h1 class="section-title"><?php echo esc_html( kmac_t('Latest Posts', 'Bài viết mới nhất') ); ?></h1>
        <div class="grid grid-3">
          <?php while ( have_posts() ) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('blog-card fade-in'); ?>>
              <?php if ( has_post_thumbnail() ) : ?>
                <a href="<?php the_permalink(); ?>">
                  <?php the_post_thumbnail('kmac-card', array('loading' => 'lazy')); ?>
                </a>
              <?php endif; ?>
              <div class="blog-content">
                <h2 style="font-size:1.1rem;margin-bottom:8px;">
                  <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </h2>
                <div class="blog-meta">
                  <span><?php echo get_the_date(); ?></span>
                  <span><?php echo esc_html( get_the_author() ); ?></span>
                </div>
                <?php the_excerpt(); ?>
              </div>
            </article>
          <?php endwhile; ?>
        </div>

        <?php the_posts_pagination(array(
          'mid_size'  => 2,
          'prev_text' => kmac_t('← Previous', '← Trước'),
          'next_text' => kmac_t('Next →', 'Tiếp →'),
        )); ?>
      </div>
    </section>

  <?php else : ?>
    <section style="text-align:center;padding:80px 24px;">
      <div class="container">
        <div style="font-size:4rem;margin-bottom:16px;">📭</div>
        <h1><?php echo esc_html( kmac_t('Nothing found', 'Không tìm thấy nội dung') ); ?></h1>
        <p style="color:var(--text-sec);margin-top:12px;">
          <?php echo esc_html( kmac_t('Try searching or browse our shop.', 'Hãy thử tìm kiếm hoặc xem cửa hàng.') ); ?>
        </p>
        <a href="<?php echo esc_url( home_url('/') ); ?>" class="btn btn-primary" style="margin-top:24px;">
          <?php echo esc_html( kmac_t('Go Home', 'Về trang chủ') ); ?>
        </a>
      </div>
    </section>
  <?php endif; ?>

</main>

<?php get_footer(); ?>
