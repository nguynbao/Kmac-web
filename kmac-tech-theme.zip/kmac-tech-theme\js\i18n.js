/* ===== KMAC Tech — i18n (EN/VN) v2.0 ===== */
const TRANSLATIONS = {
  en: {
    'nav.home': 'Home', 'nav.shop': 'Shop', 'nav.blog': 'Blog', 'nav.cart': 'Cart',
    'hero.title.1': 'Premium Accessories for Your', 'hero.title.2': 'Everyday Tech',
    'hero.desc': 'Discover cute, durable, and stylish accessories designed for MacBook lovers and gaming enthusiasts. Made with care, shipped free across the US.',
    'hero.cta': 'Shop Now →', 'hero.browse': 'Browse Collections',
    'trust.shipping': 'Free US Shipping', 'trust.returns': '30-Day Returns',
    'trust.support': '24/7 Support', 'trust.secure': 'Secure Checkout',
    'cat.title': 'Shop by Category', 'cat.subtitle': 'Find the perfect accessory for your setup',
    'cat.cases': 'MacBook Cases', 'cat.sleeves': 'Sleeves & Bags',
    'cat.gaming': 'Gaming Gear', 'cat.chargers': 'Chargers & Cables',
    'best.title': 'Bestsellers', 'best.viewall': 'View All Products',
    'brand.title': 'Why Choose KMAC Tech?', 'brand.cta': 'Start Shopping',
    'news.title': 'Stay in the Loop', 'news.placeholder': 'Enter your email address', 'news.btn': 'Subscribe',
    'cart.title': 'Shopping Cart', 'cart.empty': 'Your cart is empty',
    'cart.continue': 'Continue Shopping', 'cart.summary': 'Order Summary',
    'cart.subtotal': 'Subtotal', 'cart.shipping': 'Shipping', 'cart.free': 'FREE',
    'cart.total': 'Total', 'cart.checkout': 'Proceed to Checkout',
    'cart.coupon': 'Coupon code', 'cart.apply': 'Apply',
    'ck.title': 'Checkout', 'ck.contact': 'Contact Information',
    'ck.shipping': 'Shipping Address', 'ck.method': 'Shipping Method',
    'ck.payment': 'Payment', 'ck.place': 'Place Order',
    'ck.standard': 'Standard Shipping', 'ck.standard.time': '3-5 business days',
    'ck.express': 'Express Shipping', 'ck.express.time': '1-2 business days',
    'prod.addcart': 'Add to Cart', 'prod.desc': 'Description', 'prod.specs': 'Specifications',
    'prod.shipret': 'Shipping & Returns', 'prod.reviews': 'Customer Reviews',
    'btn.addcart': 'Add to Cart',
    'filter.laptops': 'Laptops', 'filter.mbpro': 'MacBook Pro (M1-M4)',
    'filter.mbair': 'MacBook Air', 'filter.gaming': 'Gaming Laptops',
    'filter.protection': 'Protection', 'filter.iphonecases': 'iPhone Cases (12-17 Pro Max)',
    'filter.skins': 'MacBook Full-body Skins', 'filter.sleeves': 'Sleeves & Bags',
    'filter.peripherals': 'Peripherals', 'filter.hdmi': 'High-speed HDMI',
    'filter.hubs': 'USB-C 10-in-1 Hubs', 'filter.adapters': 'Adapters & Cables',
    'filter.price': 'Price Range', 'filter.rating': 'Rating', 'filter.clear': 'Clear Filters',
  },
  vn: {
    'nav.home': 'Trang chu', 'nav.shop': 'Cua hang', 'nav.blog': 'Blog', 'nav.cart': 'Gio hang',
    'hero.title.1': 'Phu kien cao cap cho', 'hero.title.2': 'Cong nghe hang ngay',
    'hero.cta': 'Mua ngay', 'hero.browse': 'Xem bo suu tap',
    'trust.shipping': 'Mien phi van chuyen', 'trust.returns': 'Doi tra 30 ngay',
    'trust.support': 'Ho tro 24/7', 'trust.secure': 'Thanh toan an toan',
    'cat.title': 'Danh muc san pham',
    'cat.cases': 'Op MacBook', 'cat.sleeves': 'Tui & Bao',
    'cat.gaming': 'Gaming', 'cat.chargers': 'Sac & Cap',
    'best.title': 'Ban chay nhat', 'best.viewall': 'Xem tat ca',
    'brand.title': 'Tai sao chon KMAC Tech?', 'brand.cta': 'Bat dau mua sam',
    'news.title': 'Dung bo lo', 'news.placeholder': 'Nhap email cua ban', 'news.btn': 'Dang ky',
    'cart.title': 'Gio hang', 'cart.empty': 'Gio hang trong',
    'cart.continue': 'Tiep tuc mua sam', 'cart.summary': 'Tom tat don hang',
    'cart.subtotal': 'Tam tinh', 'cart.shipping': 'Van chuyen', 'cart.free': 'MIEN PHI',
    'cart.total': 'Tong cong', 'cart.checkout': 'Thanh toan',
    'cart.coupon': 'Ma giam gia', 'cart.apply': 'Ap dung',
    'ck.title': 'Thanh toan', 'ck.place': 'Dat hang',
    'prod.addcart': 'Them vao gio', 'prod.desc': 'Mo ta', 'prod.specs': 'Thong so',
    'btn.addcart': 'Them vao gio',
    'filter.laptops': 'Laptop', 'filter.protection': 'Bao ve',
    'filter.peripherals': 'Phu kien', 'filter.price': 'Khoang gia',
    'filter.rating': 'Danh gia', 'filter.clear': 'Xoa bo loc',
  }
};

function getLang() { return localStorage.getItem('kmac_lang') || 'en'; }
function setLang(lang) { localStorage.setItem('kmac_lang', lang); }
function t(key) { return (TRANSLATIONS[getLang()] || TRANSLATIONS.en)[key] || key; }

function applyTranslations() {
  const lang = getLang();
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    const text = t(key);
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') el.placeholder = text;
    else el.textContent = text;
  });
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === lang);
  });
  document.documentElement.lang = lang === 'vn' ? 'vi' : 'en';
}

function switchLang(lang) {
  setLang(lang);
  applyTranslations();
  const url = new URL(window.location);
  if (lang === 'en') url.searchParams.delete('lang');
  else url.searchParams.set('lang', lang);
  window.history.replaceState({}, '', url);
}

document.addEventListener('DOMContentLoaded', () => {
  const urlLang = new URLSearchParams(window.location.search).get('lang');
  if (urlLang && (urlLang === 'en' || urlLang === 'vn')) setLang(urlLang);
  applyTranslations();
});
