<?php
/**
 * KMAC Tech — Footer Template v5.1 (Hardened)
 * Bilingual EN/VN, wp_footer() hook required for all enqueued scripts.
 * All WC calls guarded with kmac_wc_active().
 *
 * @package KMACTech
 * @version 5.1.0
 */

$wc = kmac_wc_active();
$shop_url = $wc ? get_permalink( wc_get_page_id('shop') ) : home_url('/shop/');
?>
<footer class="footer" role="contentinfo">
  <div class="container">
    <div class="footer-grid">

      <div class="footer-brand">
        <div class="logo">KMAC<span class="footer-logo-white">Tech</span></div>
        <p><?php echo esc_html( kmac_t(
          'Premium tech accessories for your MacBook and gaming setup. Based in Da Nang, shipping to the US nationwide. 🇺🇸',
          'Phụ kiện công nghệ cao cấp cho MacBook và gaming. Giao hàng toàn nước Mỹ. 🇺🇸'
        ) ); ?></p>
      </div>

      <div>
        <h4><?php echo esc_html( kmac_t('Shop', 'Cửa hàng') ); ?></h4>
        <div class="footer-links">
          <a href="<?php echo esc_url( $shop_url ); ?>"><?php echo esc_html( kmac_t('All Products', 'Tất cả sản phẩm') ); ?></a>
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'macbook-pro', $shop_url) ); ?>"><?php echo esc_html( kmac_t('MacBook Pro Cases', 'Ốp MacBook Pro') ); ?></a>
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'iphone-cases', $shop_url) ); ?>"><?php echo esc_html( kmac_t('iPhone Cases', 'Ốp iPhone') ); ?></a>
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'usb-c-hubs', $shop_url) ); ?>"><?php echo esc_html( kmac_t('USB-C Hubs', 'Hub USB-C') ); ?></a>
        </div>
      </div>

      <div>
        <h4><?php echo esc_html( kmac_t('Help', 'Hỗ trợ') ); ?></h4>
        <div class="footer-links">
          <?php wp_nav_menu(array('theme_location' => 'footer', 'container' => false, 'items_wrap' => '%3$s', 'depth' => 1, 'fallback_cb' => false)); ?>
          <a href="#"><?php echo esc_html( kmac_t('Contact Us', 'Liên hệ') ); ?></a>
          <a href="#"><?php echo esc_html( kmac_t('Shipping Policy', 'Chính sách vận chuyển') ); ?></a>
          <a href="#"><?php echo esc_html( kmac_t('Returns & Refunds', 'Đổi trả & Hoàn tiền') ); ?></a>
          <a href="#"><?php echo esc_html( kmac_t('FAQ', 'Câu hỏi thường gặp') ); ?></a>
        </div>
      </div>

      <div>
        <h4><?php echo esc_html( kmac_t('Follow Us', 'Theo dõi') ); ?></h4>
        <div class="footer-links">
          <a href="#" rel="noopener noreferrer" target="_blank">Instagram</a>
          <a href="#" rel="noopener noreferrer" target="_blank">TikTok</a>
          <a href="#" rel="noopener noreferrer" target="_blank">Twitter / X</a>
          <a href="#" rel="noopener noreferrer" target="_blank">YouTube</a>
        </div>
      </div>

    </div>

    <div class="footer-bottom">
      <span>&copy; <?php echo esc_html( date('Y') ); ?> KMAC Tech. <?php echo esc_html( kmac_t('All rights reserved.', 'Bảo lưu mọi quyền.') ); ?></span>
      <div class="payment-icons" aria-label="<?php echo esc_attr( kmac_t('Accepted payment methods', 'Phương thức thanh toán') ); ?>">
        <span>Visa</span><span>Mastercard</span><span>PayPal</span><span>Apple Pay</span><span>VietQR</span>
      </div>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
