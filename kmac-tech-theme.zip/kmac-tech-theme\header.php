<?php
/**
 * KMAC Tech — Header Template v5.1 (Hardened)
 * Mega-menu: MacBook | Protection | Connectivity
 * Includes: EN/VN Switcher, Search, My Account, Cart
 *
 * All WC calls guarded with kmac_wc_active() to prevent
 * Fatal Error when WooCommerce is inactive.
 *
 * @package KMACTech
 * @version 5.1.0
 */

$wc = kmac_wc_active();
$shop_url = $wc ? get_permalink( wc_get_page_id('shop') ) : home_url('/shop/');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- A11y: Skip Nav -->
<a href="#main-content" class="skip-nav"><?php echo esc_html( kmac_t('Skip to main content', 'Bỏ qua đến nội dung chính') ); ?></a>

<header class="header" id="header" role="banner">
  <div class="container flex-between">

    <!-- Logo -->
    <a href="<?php echo esc_url( home_url('/') ); ?>" class="logo" aria-label="KMAC Tech — Home">
      KMAC<span>Tech</span>
    </a>

    <!-- Desktop Nav -->
    <nav class="nav-links" id="navLinks" aria-label="<?php echo esc_attr( kmac_t('Main navigation', 'Điều hướng chính') ); ?>">
      <a href="<?php echo esc_url( home_url('/') ); ?>" <?php echo is_front_page() ? 'class="active"' : ''; ?>>
        <?php echo esc_html( kmac_t('Home', 'Trang chủ') ); ?>
      </a>

      <!-- MacBook Dropdown -->
      <div class="nav-dropdown">
        <a href="<?php echo esc_url( $shop_url ); ?>" class="nav-dropdown-trigger">
          <?php echo esc_html( kmac_t('MacBook', 'MacBook') ); ?>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>
        </a>
        <div class="nav-dropdown-menu">
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'macbook-pro', $shop_url) ); ?>"><?php echo esc_html( kmac_t('MacBook Pro (M1–M4)', 'MacBook Pro (M1–M4)') ); ?></a>
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'macbook-air', $shop_url) ); ?>"><?php echo esc_html( kmac_t('MacBook Air', 'MacBook Air') ); ?></a>
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'macbook-bestsellers', $shop_url) ); ?>"><?php echo esc_html( kmac_t('Bestsellers', 'Bán chạy') ); ?></a>
        </div>
      </div>

      <!-- Protection Dropdown -->
      <div class="nav-dropdown">
        <a href="<?php echo esc_url( $shop_url ); ?>" class="nav-dropdown-trigger">
          <?php echo esc_html( kmac_t('Protection', 'Bảo vệ') ); ?>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>
        </a>
        <div class="nav-dropdown-menu">
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'iphone-cases', $shop_url) ); ?>"><?php echo esc_html( kmac_t('iPhone Cases (12–17 Pro Max)', 'Ốp iPhone (12–17 Pro Max)') ); ?></a>
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'macbook-skins', $shop_url) ); ?>"><?php echo esc_html( kmac_t('MacBook Skins', 'Skin MacBook') ); ?></a>
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'sleeves', $shop_url) ); ?>"><?php echo esc_html( kmac_t('Sleeves & Bags', 'Túi & Bao') ); ?></a>
        </div>
      </div>

      <!-- Connectivity Dropdown -->
      <div class="nav-dropdown">
        <a href="<?php echo esc_url( $shop_url ); ?>" class="nav-dropdown-trigger">
          <?php echo esc_html( kmac_t('Connectivity', 'Kết nối') ); ?>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>
        </a>
        <div class="nav-dropdown-menu">
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'hdmi-adapters', $shop_url) ); ?>"><?php echo esc_html( kmac_t('HDMI Adapters', 'Adapter HDMI') ); ?></a>
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'usb-c-hubs', $shop_url) ); ?>"><?php echo esc_html( kmac_t('USB-C Hubs', 'Hub USB-C') ); ?></a>
          <a href="<?php echo esc_url( add_query_arg('product_cat', 'chargers', $shop_url) ); ?>"><?php echo esc_html( kmac_t('Chargers & Cables', 'Sạc & Cáp') ); ?></a>
        </div>
      </div>

      <a href="<?php echo esc_url( get_permalink( get_option('page_for_posts') ) ); ?>">
        <?php echo esc_html( kmac_t('Blog', 'Blog') ); ?>
      </a>
    </nav>

    <!-- Header Actions -->
    <div class="header-actions">
      <?php get_template_part('template-parts/lang-switcher'); ?>

      <!-- Search -->
      <button class="btn-icon" data-search-toggle aria-label="<?php echo esc_attr( kmac_t('Search', 'Tìm kiếm') ); ?>">
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
      </button>

      <!-- My Account -->
      <?php
      $account_url = $wc ? get_permalink( get_option('woocommerce_myaccount_page_id') ) : wp_login_url();
      ?>
      <a href="<?php echo esc_url( $account_url ); ?>" class="btn-icon" aria-label="<?php echo esc_attr( kmac_t('My Account', 'Tài khoản') ); ?>">
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      </a>

      <!-- Cart -->
      <?php
      $cart_url = $wc ? wc_get_cart_url() : home_url('/cart/');
      $cart_count = ( $wc && WC()->cart ) ? WC()->cart->get_cart_contents_count() : 0;
      ?>
      <a href="<?php echo esc_url( $cart_url ); ?>" class="btn-icon" aria-label="<?php echo esc_attr( kmac_t('Shopping Cart', 'Giỏ hàng') ); ?>">
        <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
        <span class="cart-count" aria-label="<?php echo esc_attr( kmac_t('Cart items', 'Sản phẩm') ); ?>"><?php echo esc_html( $cart_count ); ?></span>
      </a>

      <!-- Mobile Toggle -->
      <button class="mobile-toggle" id="mobileToggle" aria-label="<?php echo esc_attr( kmac_t('Toggle menu', 'Mở menu') ); ?>" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
    </div>

  </div>
</header>

<!-- Mobile Menu -->
<div class="mobile-menu" id="mobileMenu" role="navigation" aria-label="<?php echo esc_attr( kmac_t('Mobile navigation', 'Điều hướng di động') ); ?>">
  <a href="<?php echo esc_url( home_url('/') ); ?>">🏠 <?php echo esc_html( kmac_t('Home', 'Trang chủ') ); ?></a>
  <a href="<?php echo esc_url( add_query_arg('product_cat', 'macbook-pro', $shop_url) ); ?>">💻 <?php echo esc_html( kmac_t('MacBook Pro', 'MacBook Pro') ); ?></a>
  <a href="<?php echo esc_url( add_query_arg('product_cat', 'iphone-cases', $shop_url) ); ?>">📱 <?php echo esc_html( kmac_t('iPhone Cases', 'Ốp iPhone') ); ?></a>
  <a href="<?php echo esc_url( add_query_arg('product_cat', 'usb-c-hubs', $shop_url) ); ?>">🔌 <?php echo esc_html( kmac_t('Hubs & Adapters', 'Hub & Adapter') ); ?></a>
  <a href="<?php echo esc_url( get_permalink( get_option('page_for_posts') ) ); ?>">📝 <?php echo esc_html( kmac_t('Blog', 'Blog') ); ?></a>
  <a href="<?php echo esc_url( $cart_url ); ?>">🛒 <?php echo esc_html( kmac_t('Cart', 'Giỏ hàng') ); ?></a>
  <?php $current_lang = kmac_get_lang(); ?>
  <div class="lang-switcher" style="margin-top:16px;align-self:center;">
    <a href="<?php echo esc_url( add_query_arg('lang', 'en') ); ?>" class="lang-btn <?php echo $current_lang === 'en' ? 'active' : ''; ?>">🇺🇸 EN</a>
    <a href="<?php echo esc_url( add_query_arg('lang', 'vn') ); ?>" class="lang-btn <?php echo $current_lang === 'vn' ? 'active' : ''; ?>">🇻🇳 VN</a>
  </div>
</div>
