<?php
/**
 * KMAC Tech — WordPress/WooCommerce Theme Functions
 *
 * Production-ready functions.php (Hardened)
 * Performance-optimized for LCP < 2.5s (US market)
 * Design System: Tech Blue (#3B82F6), 14px radius
 * Bilingual EN/VN with server-side session + cookie persistence
 *
 * @package KMACTech
 * @author  Giang Tran
 * @version 1.0
 */

// ============================================================
// 0. WOOCOMMERCE ACTIVE CHECK (Prevents Fatal Error)
// ============================================================
function kmac_wc_active() {
    return class_exists( 'WooCommerce' );
}

// ============================================================
// 1. THEME SETUP
// ============================================================
function kmac_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption'));
    add_theme_support('custom-logo');

    // WooCommerce support — safe even if WC not installed
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');

    register_nav_menus(array(
        'primary' => __('Primary Navigation', 'kmac-tech'),
        'mobile'  => __('Mobile Navigation', 'kmac-tech'),
        'footer'  => __('Footer Navigation', 'kmac-tech'),
    ));
}
add_action('after_setup_theme', 'kmac_theme_setup');

// ============================================================
// 2. ENQUEUE STYLES & SCRIPTS
// ============================================================
function kmac_enqueue_assets() {
    $ver = wp_get_theme()->get('Version');
    $uri = get_template_directory_uri();

    // Core Design System
    wp_enqueue_style('kmac-design', $uri . '/css/kmac-design-system.css', array(), $ver);
    wp_enqueue_style('kmac-pages',  $uri . '/css/pages.css', array('kmac-design'), $ver);
    wp_enqueue_style('kmac-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Poppins:wght@400;500;600;700;800&display=swap',
        array(), null);

    // Scripts
    wp_enqueue_script('kmac-main', $uri . '/js/main.js', array(), $ver, true);
    wp_enqueue_script('kmac-i18n', $uri . '/js/i18n.js', array('kmac-main'), $ver, true);

    // Localize for AJAX + lang
    wp_localize_script('kmac-i18n', 'KMAC_SERVER', array(
        'lang'    => kmac_get_lang(),
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('kmac_qr_nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'kmac_enqueue_assets');

// Preconnect hints for Google Fonts (performance)
function kmac_preconnect() {
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}
add_action('wp_head', 'kmac_preconnect', 1);

// ============================================================
// 3. DISABLE WOOCOMMERCE & WP BLOAT (LCP < 2.5s)
// ============================================================
function kmac_remove_bloat() {
    // WooCommerce CSS — only dequeue if WC is active
    if ( kmac_wc_active() ) {
        wp_dequeue_style('woocommerce-general');
        wp_dequeue_style('woocommerce-layout');
        wp_dequeue_style('woocommerce-smallscreen');
        wp_dequeue_style('wc-blocks-style');
        wp_dequeue_style('wc-blocks-vendors-style');
        add_filter('woocommerce_enqueue_styles', '__return_empty_array');

        if ( ! is_cart() && ! is_checkout() ) {
            wp_dequeue_script('wc-cart-fragments');
        }
        if ( ! is_checkout() ) {
            wp_dequeue_style('select2');
            wp_dequeue_script('select2');
            wp_dequeue_script('selectWoo');
        }
    }

    // WP bloat
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('wp-block-library-theme');
    wp_dequeue_style('global-styles');
    if ( ! is_user_logged_in() ) wp_dequeue_style('dashicons');
    wp_deregister_script('wp-embed');

    // Emoji & unnecessary head items
    remove_action('wp_head', 'print_emoji_detection_script', 7);
    remove_action('wp_print_styles', 'print_emoji_styles');
    remove_action('wp_head', 'wp_oembed_add_discovery_links');
    remove_action('wp_head', 'wp_oembed_add_host_js');
    remove_action('wp_head', 'rsd_link');
    remove_action('wp_head', 'wlwmanifest_link');
    remove_action('wp_head', 'wp_shortlink_wp_head');
    remove_action('wp_head', 'wp_generator');
    remove_action('wp_head', 'rest_output_link_wp_head');
}
add_action('wp_enqueue_scripts', 'kmac_remove_bloat', 100);

// ============================================================
// 4. SECURITY HARDENING
// ============================================================
add_filter('xmlrpc_enabled', '__return_false');
add_filter('the_generator', '__return_empty_string');

function kmac_security_headers() {
    if ( ! is_admin() && ! headers_sent() ) {
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: SAMEORIGIN');
        header('X-XSS-Protection: 1; mode=block');
        header('Referrer-Policy: strict-origin-when-cross-origin');
    }
}
add_action('send_headers', 'kmac_security_headers');

function kmac_restrict_rest_api($result) {
    if ( is_user_logged_in() ) return $result;
    $route = $GLOBALS['wp']->query_vars['rest_route'] ?? '';
    if ( str_starts_with($route, '/wc/store') || str_starts_with($route, '/wc/v3') ) return $result;
    return new WP_Error('rest_forbidden', 'REST API restricted.', array('status' => 403));
}
add_filter('rest_authentication_errors', 'kmac_restrict_rest_api');

// ============================================================
// 5. IMAGE & MEDIA
// ============================================================
function kmac_webp_support($mimes) {
    $mimes['webp'] = 'image/webp';
    return $mimes;
}
add_filter('upload_mimes', 'kmac_webp_support');

function kmac_image_sizes() {
    add_image_size('kmac-card',    400, 400, true);
    add_image_size('kmac-gallery', 600, 600, true);
    add_image_size('kmac-hero',   1200, 600, true);
}
add_action('after_setup_theme', 'kmac_image_sizes');

// ============================================================
// 6. LANGUAGE SWITCHER (EN/VN) — Server-side
// ============================================================
function kmac_start_session() {
    if ( ! session_id() && ! headers_sent() ) {
        session_start([
            'cookie_lifetime' => 86400 * 30,
            'cookie_httponly'  => true,
            'cookie_samesite'  => 'Lax',
        ]);
    }
}
add_action('init', 'kmac_start_session', 1);

function kmac_process_lang_switch() {
    if ( isset($_GET['lang']) ) {
        $raw = sanitize_text_field( wp_unslash( $_GET['lang'] ) );
        if ( in_array($raw, array('en', 'vn'), true) ) {
            $_SESSION['kmac_lang'] = $raw;
            setcookie('kmac_lang', $raw, time() + (86400 * 30), '/', '', is_ssl(), true);
            if ( ! wp_doing_ajax() ) {
                wp_safe_redirect( remove_query_arg('lang') );
                exit;
            }
        }
    }
}
add_action('init', 'kmac_process_lang_switch', 2);

function kmac_get_lang() {
    // Priority: session > cookie > default
    if ( isset($_SESSION['kmac_lang']) ) {
        $lang = sanitize_text_field( $_SESSION['kmac_lang'] );
        if ( in_array($lang, array('en', 'vn'), true) ) return $lang;
    }
    if ( isset($_COOKIE['kmac_lang']) ) {
        $lang = sanitize_text_field( wp_unslash( $_COOKIE['kmac_lang'] ) );
        if ( in_array($lang, array('en', 'vn'), true) ) return $lang;
    }
    return 'en';
}

function kmac_t( $en, $vn ) {
    return kmac_get_lang() === 'vn' ? $vn : $en;
}

add_filter('locale', function($locale) {
    return kmac_get_lang() === 'vn' ? 'vi' : $locale;
});

// ============================================================
// 7. BILINGUAL ORDER EMAILS (WC-guarded)
// ============================================================
function kmac_bilingual_email_subject( $subject, $order ) {
    if ( ! kmac_wc_active() || ! $order ) return $subject;
    if ( $order->get_meta('_kmac_order_lang') !== 'vn' ) return $subject;
    $vn = array(
        'on-hold'    => 'Đơn hàng #%d — Đang chờ thanh toán',
        'processing' => 'Đơn hàng #%d — Đang xử lý',
        'completed'  => 'Đơn hàng #%d — Hoàn tất!',
        'cancelled'  => 'Đơn hàng #%d — Đã hủy',
    );
    $status = $order->get_status();
    return isset($vn[$status]) ? sprintf($vn[$status], $order->get_id()) : $subject;
}
add_filter('woocommerce_email_subject_customer_on_hold_order',    'kmac_bilingual_email_subject', 10, 2);
add_filter('woocommerce_email_subject_customer_processing_order', 'kmac_bilingual_email_subject', 10, 2);
add_filter('woocommerce_email_subject_customer_completed_order',  'kmac_bilingual_email_subject', 10, 2);

function kmac_bilingual_email_instructions( $order, $sent_to_admin ) {
    if ( ! kmac_wc_active() ) return;
    if ( $sent_to_admin || $order->get_payment_method() !== 'kmac_direct_pay' ) return;
    if ( $order->get_status() !== 'on-hold' ) return;
    $lang = $order->get_meta('_kmac_order_lang');
    $desc = 'KMAC' . $order->get_id();
    if ( $lang === 'vn' ) {
        echo '<h2>Hướng dẫn thanh toán</h2>';
        echo '<p>Nội dung chuyển khoản: <strong>' . esc_html($desc) . '</strong></p>';
        echo '<p>Ngân hàng: <strong>' . esc_html(KMAC_VIETQR_BANK_ID) . '</strong> — STK: <strong>' . esc_html(KMAC_VIETQR_ACCOUNT_NO) . '</strong></p>';
    } else {
        echo '<h2>Payment Instructions</h2>';
        echo '<p>Transfer description: <strong>' . esc_html($desc) . '</strong></p>';
        echo '<p>Bank: <strong>' . esc_html(KMAC_VIETQR_BANK_ID) . '</strong> — Account: <strong>' . esc_html(KMAC_VIETQR_ACCOUNT_NO) . '</strong></p>';
    }
}
add_action('woocommerce_email_before_order_table', 'kmac_bilingual_email_instructions', 10, 4);

// ============================================================
// 8. PAYMENT GATEWAY — KMAC DIRECT PAY
// ============================================================
if ( ! defined('KMAC_VIETQR_BANK_ID') )     define('KMAC_VIETQR_BANK_ID',     'MB');
if ( ! defined('KMAC_VIETQR_ACCOUNT_NO') )  define('KMAC_VIETQR_ACCOUNT_NO',  '0123456789');
if ( ! defined('KMAC_VIETQR_ACCOUNT_NAME')) define('KMAC_VIETQR_ACCOUNT_NAME','KMAC TECH');
if ( ! defined('KMAC_BINANCE_WALLET') )     define('KMAC_BINANCE_WALLET',     'TXxxx');
if ( ! defined('KMAC_BINANCE_NETWORK') )    define('KMAC_BINANCE_NETWORK',    'TRC-20');

add_filter('woocommerce_payment_gateways', function($gateways) {
    if ( class_exists('WC_Gateway_KMAC_Direct_Pay') ) {
        $gateways[] = 'WC_Gateway_KMAC_Direct_Pay';
    }
    return $gateways;
});

function kmac_init_direct_pay_gateway() {
    if ( ! class_exists('WC_Payment_Gateway') ) return;

    class WC_Gateway_KMAC_Direct_Pay extends WC_Payment_Gateway {
        public function __construct() {
            $this->id                 = 'kmac_direct_pay';
            $this->has_fields         = false;
            $this->method_title       = 'KMAC Direct Pay';
            $this->method_description = 'VietQR bank transfer + Binance USDT. QR shown on Thank You page.';
            $this->init_form_fields();
            $this->init_settings();
            $this->title       = $this->get_option('title', '💳 KMAC Direct Pay');
            $this->description = $this->get_option('description', kmac_t('Pay via bank transfer or crypto.','Thanh toán qua ngân hàng hoặc crypto.'));
            $this->enabled     = $this->get_option('enabled', 'yes');
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }
        public function init_form_fields() {
            $this->form_fields = array(
                'enabled'     => array('title' => 'Enable/Disable', 'type' => 'checkbox', 'label' => 'Enable KMAC Direct Pay', 'default' => 'yes'),
                'title'       => array('title' => 'Title', 'type' => 'text', 'default' => '💳 KMAC Direct Pay'),
                'description' => array('title' => 'Description', 'type' => 'textarea', 'default' => 'Pay via bank transfer or crypto.'),
            );
        }
        public function process_payment( $order_id ) {
            $order = wc_get_order($order_id);
            if ( ! $order ) return array('result' => 'failure');
            $order->update_status('on-hold', kmac_t('Awaiting KMAC Direct Pay.', 'Đang chờ thanh toán KMAC Direct Pay.'));
            $order->update_meta_data('_kmac_order_lang', kmac_get_lang());
            $order->save();
            wc_reduce_stock_levels($order_id);
            WC()->cart->empty_cart();
            return array('result' => 'success', 'redirect' => $this->get_return_url($order));
        }
    }
}
add_action('plugins_loaded', 'kmac_init_direct_pay_gateway');

// ============================================================
// 9. SECURE QR AJAX ENDPOINT
// ============================================================
function kmac_ajax_generate_qr() {
    check_ajax_referer('kmac_qr_nonce', 'nonce');

    if ( ! kmac_wc_active() || ! function_exists('wc_get_order') ) {
        wp_send_json_error('WooCommerce not active.', 500);
    }

    $order_id  = absint( $_POST['order_id'] ?? 0 );
    $order_key = sanitize_text_field( wp_unslash( $_POST['order_key'] ?? '' ) );
    $order     = wc_get_order($order_id);

    if ( ! $order || $order->get_order_key() !== $order_key ) {
        wp_send_json_error('Unauthorized.', 403);
    }

    $amount      = intval( $order->get_total() );
    $description = 'KMAC' . $order->get_id();

    wp_send_json_success(array(
        'vietqr_url'      => sprintf(
            'https://img.vietqr.io/image/%s-%s-compact2.png?amount=%d&addInfo=%s&accountName=%s',
            rawurlencode(KMAC_VIETQR_BANK_ID),
            rawurlencode(KMAC_VIETQR_ACCOUNT_NO),
            $amount,
            rawurlencode($description),
            rawurlencode(KMAC_VIETQR_ACCOUNT_NAME)
        ),
        'bank_id'         => KMAC_VIETQR_BANK_ID,
        'account_no'      => KMAC_VIETQR_ACCOUNT_NO,
        'account_name'    => KMAC_VIETQR_ACCOUNT_NAME,
        'amount'          => $amount,
        'transfer_desc'   => $description,
        'binance_wallet'  => KMAC_BINANCE_WALLET,
        'binance_network' => KMAC_BINANCE_NETWORK,
        'order_total_usd' => $order->get_total(),
        'lang'            => kmac_get_lang(),
    ));
}
add_action('wp_ajax_kmac_generate_qr',        'kmac_ajax_generate_qr');
add_action('wp_ajax_nopriv_kmac_generate_qr', 'kmac_ajax_generate_qr');

// ============================================================
// 10. JSON-LD PRODUCT SCHEMA (SEO Rich Results) — WC-guarded
// ============================================================
function kmac_inject_product_schema() {
    if ( ! kmac_wc_active() ) return;
    if ( ! function_exists('is_product') || ! is_product() ) return;

    global $product;
    if ( ! $product ) $product = wc_get_product( get_the_ID() );
    if ( ! $product ) return;

    $schema = array(
        '@context'    => 'https://schema.org',
        '@type'       => 'Product',
        'name'        => $product->get_name(),
        'sku'         => $product->get_sku(),
        'url'         => get_permalink( $product->get_id() ),
        'description' => wp_strip_all_tags( $product->get_short_description() ?: $product->get_description() ),
        'brand'       => array( '@type' => 'Brand', 'name' => 'KMAC Tech' ),
        'offers'      => array(
            '@type'         => 'Offer',
            'url'           => get_permalink( $product->get_id() ),
            'priceCurrency' => get_woocommerce_currency(),
            'price'         => $product->get_price(),
            'availability'  => $product->is_in_stock() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
            'seller'        => array( '@type' => 'Organization', 'name' => 'KMAC Tech' ),
        ),
    );

    $image_id = $product->get_image_id();
    if ( $image_id ) {
        $schema['image'] = wp_get_attachment_url( $image_id );
    }

    if ( $product->get_review_count() > 0 ) {
        $schema['aggregateRating'] = array(
            '@type'       => 'AggregateRating',
            'ratingValue' => $product->get_average_rating(),
            'reviewCount' => $product->get_review_count(),
        );
    }

    echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
}
add_action('wp_head', 'kmac_inject_product_schema', 5);

// ============================================================
// 11. DATABASE OPTIMIZATION
// ============================================================
function kmac_cleanup_db() {
    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_%' AND option_value < UNIX_TIMESTAMP()");
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_wc_session_%'");
    $wpdb->query("DELETE pm FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.ID IS NULL");
    $wpdb->query("OPTIMIZE TABLE {$wpdb->options}");
    if ( function_exists('wc_delete_product_transients') ) {
        wc_delete_product_transients();
    }
    return true;
}
add_action('wp', function() {
    if ( ! wp_next_scheduled('kmac_weekly_db_cleanup') ) {
        wp_schedule_event( time(), 'weekly', 'kmac_weekly_db_cleanup' );
    }
});
add_action('kmac_weekly_db_cleanup', 'kmac_cleanup_db');

// ============================================================
// 12. ADMIN NOTICES (WC-guarded)
// ============================================================
function kmac_admin_notice() {
    if ( ! kmac_wc_active() || ! function_exists('wc_orders_count') ) return;
    if ( ! current_user_can('manage_woocommerce') ) return;
    $count = wc_orders_count('on-hold');
    if ( $count > 0 ) {
        printf(
            '<div class="notice notice-warning"><p><strong>KMAC Direct Pay:</strong> %d %s <a href="%s">%s</a></p></div>',
            $count,
            kmac_t('orders awaiting payment.', 'đơn hàng chờ thanh toán.'),
            esc_url( admin_url('edit.php?post_type=shop_order&post_status=wc-on-hold') ),
            kmac_t('View →', 'Xem →')
        );
    }
}
add_action('admin_notices', 'kmac_admin_notice');
