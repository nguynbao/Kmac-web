<?php
/**
 * KMAC Tech — Single Product Tabs (Override)
 *
 * Fixes AJAX/Tab loading state during language switching.
 * Uses Vanilla JS for tab management with no heavy libraries.
 * Enforces H2/H3 heading hierarchy per SEO spec.
 *
 * @package KMACTech
 * @version 2.0
 * @see woocommerce/single-product/tabs/tabs.php
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$product_tabs = apply_filters( 'woocommerce_product_tabs', array() );
if ( empty( $product_tabs ) ) return;
?>

<div class="kmac-product-tabs" id="kmacProductTabs" role="tablist" aria-label="<?php echo kmac_t('Product Information', 'Thông tin sản phẩm'); ?>">

  <div class="kmac-tabs-nav">
    <?php $i = 0; foreach ( $product_tabs as $key => $tab ) : ?>
      <button
        class="kmac-tab-btn <?php echo $i === 0 ? 'active' : ''; ?>"
        role="tab"
        id="tab-<?php echo esc_attr( $key ); ?>"
        aria-controls="panel-<?php echo esc_attr( $key ); ?>"
        aria-selected="<?php echo $i === 0 ? 'true' : 'false'; ?>"
        data-tab="<?php echo esc_attr( $key ); ?>"
        onclick="kmacSwitchTab('<?php echo esc_js( $key ); ?>')"
      >
        <?php echo wp_kses_post( $tab['title'] ); ?>
      </button>
    <?php $i++; endforeach; ?>
  </div>

  <?php $i = 0; foreach ( $product_tabs as $key => $tab ) : ?>
    <div
      class="kmac-tab-panel <?php echo $i === 0 ? 'active' : ''; ?>"
      role="tabpanel"
      id="panel-<?php echo esc_attr( $key ); ?>"
      aria-labelledby="tab-<?php echo esc_attr( $key ); ?>"
      <?php echo $i !== 0 ? 'hidden' : ''; ?>
    >
      <?php
      if ( isset( $tab['callback'] ) ) {
          call_user_func( $tab['callback'], $key, $tab );
      }
      ?>
    </div>
  <?php $i++; endforeach; ?>
</div>

<script>
function kmacSwitchTab(tabKey) {
  document.querySelectorAll('.kmac-tab-btn').forEach(function(btn) {
    var isActive = btn.getAttribute('data-tab') === tabKey;
    btn.classList.toggle('active', isActive);
    btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
  });
  document.querySelectorAll('.kmac-tab-panel').forEach(function(panel) {
    var isActive = panel.id === 'panel-' + tabKey;
    panel.classList.toggle('active', isActive);
    if (isActive) panel.removeAttribute('hidden');
    else panel.setAttribute('hidden', '');
  });
}
document.addEventListener('DOMContentLoaded', function() {
  var activeTab = document.querySelector('.kmac-tab-btn.active');
  if (activeTab) kmacSwitchTab(activeTab.getAttribute('data-tab'));
});
</script>

<style>
.kmac-product-tabs { margin-top: 40px; }
.kmac-tabs-nav { display: flex; border-bottom: 2px solid var(--border, #E5E7EB); overflow-x: auto; }
.kmac-tab-btn { padding: 14px 24px; font-weight: 600; font-size: .95rem; color: var(--text-sec, #4B5563); background: transparent; border: none; border-bottom: 3px solid transparent; cursor: pointer; transition: all .25s ease; white-space: nowrap; font-family: var(--font, 'Inter', sans-serif); }
.kmac-tab-btn:hover { color: var(--blue, #3B82F6); }
.kmac-tab-btn.active { color: var(--blue, #3B82F6); border-bottom-color: var(--blue, #3B82F6); }
.kmac-tab-panel { display: none; padding: 28px 0; animation: tabFadeIn .3s ease; }
.kmac-tab-panel.active { display: block; }
.kmac-tab-panel h2 { font-size: 1.3rem; margin-bottom: 16px; }
.kmac-tab-panel h3 { font-size: 1.05rem; margin-bottom: 12px; }
.kmac-tab-panel p, .kmac-tab-panel li { color: var(--text-sec, #4B5563); line-height: 1.8; font-size: .95rem; }
@keyframes tabFadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
</style>
