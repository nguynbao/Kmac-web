<?php
/**
 * KMAC Tech — Product Card Component
 *
 * Usage: get_template_part('template-parts/product-card');
 * Expects $product to be set in calling context, or uses global $product.
 */
global $product;
if ( ! $product ) return;
?>
<a href="<?php echo esc_url(get_permalink($product->get_id())); ?>" class="product-card" aria-label="<?php echo esc_attr($product->get_name()); ?>">
  <div class="product-img">
    <?php if ( $product->is_on_sale() ) : ?>
      <div class="product-badges">
        <span class="badge badge-sale">
          -<?php echo round((1 - $product->get_price() / $product->get_regular_price()) * 100); ?>%
        </span>
      </div>
    <?php endif; ?>
    <?php echo $product->get_image('kmac-card', array('loading' => 'lazy')); ?>
  </div>
  <div class="product-info">
    <?php if ( $product->get_review_count() > 0 ) : ?>
      <div class="product-rating">
        <span class="stars"><?php echo wc_get_rating_html($product->get_average_rating()); ?></span>
        (<?php echo $product->get_review_count(); ?>)
      </div>
    <?php endif; ?>
    <h3 class="product-name"><?php echo esc_html($product->get_name()); ?></h3>
    <div class="product-price"><?php echo $product->get_price_html(); ?></div>
    <div class="product-actions">
      <?php woocommerce_template_loop_add_to_cart(); ?>
    </div>
  </div>
</a>
