<?php
/**
 * KMAC Tech — Front Page Template (Homepage)
 *
 * High-converting landing page for the KMAC Tech store.
 * Sections: Hero → Trust Bar → Collections → Bestsellers → Brand Strip → Newsletter
 *
 * @package KMACTech
 * @version 1.0
 */

get_header();

$wc = kmac_wc_active();
$shop_url = $wc ? get_permalink( wc_get_page_id('shop') ) : home_url('/shop/');
?>

<main id="main-content">

  <!-- ===== HERO ===== -->
  <section class="hero">
    <div class="container">
      <div class="hero-content fade-in">
        <h1>
          <?php echo esc_html( kmac_t('Premium Accessories for Your', 'Phụ kiện cao cấp cho') ); ?>
          <span class="highlight"><?php echo esc_html( kmac_t('Everyday Tech', 'Công nghệ hàng ngày') ); ?></span>
        </h1>
        <p><?php echo esc_html( kmac_t(
          'Discover cute, durable, and stylish accessories designed for MacBook lovers and gaming enthusiasts. Made with care, shipped free across the US.',
          'Khám phá phụ kiện dễ thương, bền bỉ và phong cách dành cho người yêu MacBook và game thủ. Giao hàng miễn phí toàn nước Mỹ.'
        ) ); ?></p>
        <div class="hero-actions">
          <a href="<?php echo esc_url( $shop_url ); ?>" class="btn btn-primary btn-lg">
            <?php echo esc_html( kmac_t('Shop Now →', 'Mua ngay →') ); ?>
          </a>
          <a href="<?php echo esc_url( $shop_url ); ?>" class="btn btn-outline btn-lg">
            <?php echo esc_html( kmac_t('Browse Collections', 'Xem bộ sưu tập') ); ?>
          </a>
        </div>
      </div>
      <div class="hero-image fade-in">
        <picture>
          <source srcset="<?php echo esc_url( get_template_directory_uri() . '/assets/hero-banner.webp' ); ?>" type="image/webp">
          <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/hero-banner.png' ); ?>"
               alt="KMAC Tech — Premium MacBook Accessories" width="520" height="520" loading="eager">
        </picture>
      </div>
    </div>
  </section>

  <!-- ===== TRUST BAR ===== -->
  <section class="trust-bar">
    <div class="container">
      <div class="trust-item"><div class="trust-icon">🚚</div><span><?php echo esc_html( kmac_t('Free US Shipping', 'Miễn phí vận chuyển') ); ?></span></div>
      <div class="trust-item"><div class="trust-icon">🔄</div><span><?php echo esc_html( kmac_t('30-Day Returns', 'Đổi trả 30 ngày') ); ?></span></div>
      <div class="trust-item"><div class="trust-icon">💬</div><span><?php echo esc_html( kmac_t('24/7 Support', 'Hỗ trợ 24/7') ); ?></span></div>
      <div class="trust-item"><div class="trust-icon">🔒</div><span><?php echo esc_html( kmac_t('Secure Checkout', 'Thanh toán an toàn') ); ?></span></div>
    </div>
  </section>

  <!-- ===== COLLECTIONS ===== -->
  <section class="section collections">
    <div class="container">
      <h2 class="section-title"><?php echo esc_html( kmac_t('Shop by Category', 'Danh mục sản phẩm') ); ?></h2>
      <p class="section-subtitle"><?php echo esc_html( kmac_t('Find the perfect accessory for your setup', 'Tìm phụ kiện hoàn hảo cho bạn') ); ?></p>
      <div class="grid">
        <?php
        $categories = array(
          array('icon' => '💻', 'slug' => 'macbook-pro', 'en' => 'MacBook Cases',     'vn' => 'Ốp MacBook',   'en_d' => 'Hard shell & soft covers',  'vn_d' => 'Ốp cứng & mềm'),
          array('icon' => '🎒', 'slug' => 'sleeves',     'en' => 'Sleeves & Bags',    'vn' => 'Túi & Bao',     'en_d' => 'Carry in style',            'vn_d' => 'Mang theo phong cách'),
          array('icon' => '🎮', 'slug' => 'gaming',      'en' => 'Gaming Gear',       'vn' => 'Gaming',        'en_d' => 'Mousepads, stands & more',  'vn_d' => 'Lót chuột, giá đỡ'),
          array('icon' => '⚡', 'slug' => 'chargers',    'en' => 'Chargers & Cables', 'vn' => 'Sạc & Cáp',     'en_d' => 'Fast charge, always ready', 'vn_d' => 'Sạc nhanh, luôn sẵn sàng'),
        );
        foreach ( $categories as $cat ) :
          $cat_url = add_query_arg('product_cat', $cat['slug'], $shop_url);
        ?>
          <a href="<?php echo esc_url( $cat_url ); ?>" class="collection-card fade-in">
            <div class="icon"><?php echo $cat['icon']; ?></div>
            <h3><?php echo esc_html( kmac_t($cat['en'], $cat['vn']) ); ?></h3>
            <p><?php echo esc_html( kmac_t($cat['en_d'], $cat['vn_d']) ); ?></p>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- ===== BESTSELLERS ===== -->
  <section class="section section-blue-bg">
    <div class="container">
      <h2 class="section-title"><?php echo esc_html( kmac_t('Bestsellers ⭐', 'Bán chạy nhất ⭐') ); ?></h2>
      <p class="section-subtitle"><?php echo esc_html( kmac_t("Our community's most-loved picks", 'Sản phẩm được yêu thích nhất') ); ?></p>
      <div class="grid grid-4">
        <?php
        if ( $wc ) {
          $best = wc_get_products(array(
            'limit'    => 4,
            'orderby'  => 'popularity',
            'status'   => 'publish',
            'stock_status' => 'instock',
          ));
          if ( $best ) {
            foreach ( $best as $prod ) {
              $GLOBALS['product'] = $prod;
              get_template_part('template-parts/product', 'card');
            }
            wp_reset_postdata();
          } else {
            echo '<p style="grid-column:1/-1;text-align:center;color:var(--text-sec);">' . esc_html( kmac_t('Products coming soon!', 'Sản phẩm sắp ra mắt!') ) . '</p>';
          }
        } else {
          echo '<p style="grid-column:1/-1;text-align:center;color:var(--text-sec);">' . esc_html( kmac_t('Install WooCommerce to display products.', 'Cài đặt WooCommerce để hiển thị sản phẩm.') ) . '</p>';
        }
        ?>
      </div>
      <div class="section-center">
        <a href="<?php echo esc_url( $shop_url ); ?>" class="btn btn-primary"><?php echo esc_html( kmac_t('View All Products →', 'Xem tất cả sản phẩm →') ); ?></a>
      </div>
    </div>
  </section>

  <!-- ===== BRAND STRIP ===== -->
  <section class="brand-strip">
    <h2><?php echo esc_html( kmac_t('Why Choose KMAC Tech? 💙', 'Tại sao chọn KMAC Tech? 💙') ); ?></h2>
    <p><?php echo esc_html( kmac_t(
      'We believe your tech deserves accessories that are as unique as you. Every product is designed with love, tested for quality, and backed by our happiness guarantee.',
      'Chúng tôi tin rằng công nghệ của bạn xứng đáng có phụ kiện độc đáo. Mọi sản phẩm đều được thiết kế với tình yêu và đảm bảo chất lượng.'
    ) ); ?></p>
    <a href="<?php echo esc_url( $shop_url ); ?>" class="btn btn-white btn-lg"><?php echo esc_html( kmac_t('Start Shopping', 'Bắt đầu mua sắm') ); ?></a>
  </section>

  <!-- ===== NEWSLETTER ===== -->
  <section class="section newsletter">
    <div class="container">
      <h2 class="section-title"><?php echo esc_html( kmac_t('Stay in the Loop 💌', 'Đừng bỏ lỡ 💌') ); ?></h2>
      <p class="section-subtitle"><?php echo esc_html( kmac_t(
        'Get exclusive deals, new arrivals, and tech tips straight to your inbox.',
        'Nhận ưu đãi độc quyền và mẹo công nghệ.'
      ) ); ?></p>
      <form class="newsletter-form" action="#" method="post" aria-label="Newsletter signup">
        <label for="newsletterEmail" class="sr-only"><?php echo esc_attr( kmac_t('Email address', 'Địa chỉ email') ); ?></label>
        <input type="email" id="newsletterEmail" name="email" placeholder="<?php echo esc_attr( kmac_t('Enter your email address', 'Nhập email của bạn') ); ?>" required>
        <button type="submit" class="btn btn-primary"><?php echo esc_html( kmac_t('Subscribe', 'Đăng ký') ); ?></button>
      </form>
    </div>
  </section>

</main>

<?php get_footer(); ?>
