<?php
/**
 * KMAC Tech — Archive Template (Blog, Category, Tag)
 */
get_header(); ?>

<main id="main-content">
  <section class="blog-header">
    <div class="container">
      <h1 style="font-size:2.2rem;margin-bottom:8px;">
        <?php
        if ( is_category() )      echo 'Category: ' . single_cat_title('', false);
        elseif ( is_tag() )       echo 'Tag: ' . single_tag_title('', false);
        elseif ( is_author() )    echo 'Author: ' . get_the_author();
        elseif ( is_date() )      echo get_the_date('F Y');
        else                      echo kmac_t('Blog', 'Blog');
        ?>
      </h1>
      <p style="color:var(--text-sec);"><?php echo kmac_t('Tech guides, product tips, and everything MacBook & gaming', 'Hướng dẫn công nghệ và mẹo sản phẩm'); ?></p>
    </div>
  </section>

  <section class="blog-page">
    <div class="container">
      <?php if ( have_posts() ) : ?>
        <div class="blog-grid" style="margin-top:40px;">
          <?php while ( have_posts() ) : the_post(); ?>
            <article class="blog-card">
              <?php if ( has_post_thumbnail() ) : ?>
                <a href="<?php the_permalink(); ?>">
                  <?php the_post_thumbnail('kmac-card', array('loading' => 'lazy')); ?>
                </a>
              <?php endif; ?>
              <div class="blog-content">
                <div class="blog-tag"><?php the_category(', '); ?></div>
                <h2 style="font-size:1.05rem;margin-bottom:8px;line-height:1.4;">
                  <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </h2>
                <p><?php the_excerpt(); ?></p>
                <div class="blog-meta">
                  <span><?php echo get_the_date(); ?></span>
                  <span><?php echo ceil(str_word_count(get_the_content()) / 200); ?> min read</span>
                </div>
              </div>
            </article>
          <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <div style="text-align:center;margin-top:48px;">
          <?php the_posts_pagination(array(
            'prev_text' => '← ' . kmac_t('Previous', 'Trước'),
            'next_text' => kmac_t('Next', 'Tiếp theo') . ' →',
          )); ?>
        </div>

      <?php else : ?>
        <p style="text-align:center;padding:60px;color:var(--text-sec);"><?php echo kmac_t('No posts found.', 'Không có bài viết.'); ?></p>
      <?php endif; ?>
    </div>
  </section>
</main>

<?php get_footer(); ?>
