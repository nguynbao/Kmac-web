/* ===== Product Detail JS v2.0 ===== */
const SAMPLE_REVIEWS = [
  { name: 'Sarah M.', date: 'Apr 28, 2026', rating: 5, text: 'Absolutely love this! The quality is amazing and it fits my MacBook perfectly.', verified: true },
  { name: 'James K.', date: 'Apr 15, 2026', rating: 5, text: 'Great build quality and the packaging was really cute. Will definitely buy more from KMAC Tech.', verified: true },
  { name: 'Emily R.', date: 'Mar 30, 2026', rating: 4, text: 'Really nice product, looks exactly like the photos. Only giving 4 stars because I wish there were more color options.', verified: true },
  { name: 'Mike T.', date: 'Mar 12, 2026', rating: 5, text: 'This is my third purchase from KMAC Tech and they never disappoint. Premium quality at a fair price.', verified: true },
];

document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const productId = parseInt(params.get('id')) || 1;
  const product = PRODUCTS.find(p => p.id === productId) || PRODUCTS[0];

  document.title = `${product.name} — KMAC Tech`;
  const breadcrumb = document.getElementById('breadcrumbName');
  if (breadcrumb) breadcrumb.textContent = product.name;

  // Inject JSON-LD Product schema
  const schema = document.createElement('script');
  schema.type = 'application/ld+json';
  schema.textContent = JSON.stringify({
    "@context": "https://schema.org", "@type": "Product",
    "name": product.name,
    "image": `https://kmactech.com/${product.img}.webp`,
    "description": "Premium quality accessory designed for your everyday tech.",
    "brand": { "@type": "Brand", "name": "KMAC Tech" },
    "offers": {
      "@type": "Offer", "price": product.price.toFixed(2),
      "priceCurrency": "USD", "availability": "https://schema.org/InStock",
      "seller": { "@type": "Organization", "name": "KMAC Tech" }
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": product.rating.toString(),
      "reviewCount": product.reviews.toString()
    }
  });
  document.head.appendChild(schema);

  const layout = document.getElementById('productLayout');
  if (layout) layout.innerHTML = `
    <div class="gallery">
      <div class="gallery-main">
        <picture>
          <source srcset="${product.img}.webp" type="image/webp">
          <img src="${product.img}.png" alt="${product.name}" id="mainImg" width="600" height="600">
        </picture>
      </div>
      <div class="gallery-thumbs">
        <button class="active" onclick="selectThumb(this,'${product.img}')" aria-label="View image 1">
          <picture><source srcset="${product.img}.webp" type="image/webp"><img src="${product.img}.png" alt="View 1" width="72" height="72"></picture>
        </button>
        <button onclick="selectThumb(this,'${product.img}')" aria-label="View image 2">
          <picture><source srcset="${product.img}.webp" type="image/webp"><img src="${product.img}.png" alt="View 2" width="72" height="72"></picture>
        </button>
      </div>
    </div>
    <div class="product-info-detail">
      <h1>${product.name}</h1>
      <div class="product-meta">
        <div class="product-rating"><span class="stars" style="color:#FFC107">${renderStars(product.rating)}</span> <span>${product.reviews} reviews</span></div>
        ${product.badge === 'best' ? '<span class="badge badge-best">Best Seller</span>' : ''}
        ${product.badge === 'new' ? '<span class="badge badge-new">New Arrival</span>' : ''}
      </div>
      <div class="product-detail-price">$${product.price.toFixed(2)} ${product.oldPrice ? '<span class="old-price" style="font-size:1.1rem">$' + product.oldPrice.toFixed(2) + '</span>' : ''}</div>
      <p>Premium quality accessory designed for your everyday tech. Made with durable, eco-friendly materials that protect your device while looking stylish.</p>
      ${product.colors.length ? `<div style="margin:16px 0;"><label>Color: <strong id="selectedColor">${product.colors[0]}</strong></label><div class="color-swatches" style="margin-top:8px;">${product.colors.map((c, i) => `<button class="color-swatch${i === 0 ? ' active' : ''}" style="background:${getColorHex(c)}" title="${c}" aria-label="Color: ${c}" onclick="selectColor(this,'${c}')"></button>`).join('')}</div></div>` : ''}
      ${product.sizes.length ? `<div style="margin:16px 0;"><label>Size / Model</label><div class="size-options" style="margin-top:8px;">${product.sizes.map((s, i) => `<button class="size-btn${i === 0 ? ' active' : ''}" onclick="selectSize(this)" aria-label="Size: ${s}">${s}</button>`).join('')}</div></div>` : ''}
      <div style="margin:16px 0;"><label for="qtyInput">Quantity</label>
        <div class="qty-control" style="margin-top:8px;">
          <button onclick="changeQty(-1)" aria-label="Decrease">-</button>
          <input type="number" value="1" min="1" max="10" id="qtyInput" aria-label="Quantity">
          <button onclick="changeQty(1)" aria-label="Increase">+</button>
        </div>
      </div>
      <button class="btn btn-primary" style="width:100%;margin-top:8px;" onclick="addToCart(${product.id}, parseInt(document.getElementById('qtyInput').value))" id="addToCartBtn">
        Add to Cart
      </button>
    </div>`;

  const reviewsSummary = document.getElementById('reviewsSummary');
  if (reviewsSummary) reviewsSummary.innerHTML = `
    <div style="text-align:center;"><div style="font-size:3rem;font-weight:800;color:var(--blue-text);">${product.rating}.0</div>
    <div style="color:#FFC107;font-size:1.2rem;">${renderStars(product.rating)}</div>
    <div style="color:var(--text-sec);font-size:.85rem;margin-top:4px;">${product.reviews} reviews</div></div>`;

  const reviewsList = document.getElementById('reviewsList');
  if (reviewsList) reviewsList.innerHTML = SAMPLE_REVIEWS.map(r => `
    <div class="review-card">
      <div style="display:flex;justify-content:space-between;margin-bottom:8px;">
        <div><span style="font-weight:600;">${r.name}</span>${r.verified ? ' <span class="badge badge-new" style="font-size:.65rem;">Verified</span>' : ''}</div>
        <span style="color:var(--text-muted);font-size:.8rem;">${r.date}</span>
      </div>
      <div style="color:#FFC107;margin-bottom:8px;">${renderStars(r.rating)}</div>
      <p style="color:var(--text-sec);line-height:1.7;">${r.text}</p>
    </div>`).join('');

  const relatedGrid = document.getElementById('relatedGrid');
  if (relatedGrid) {
    const related = PRODUCTS.filter(p => p.id !== product.id).slice(0, 4);
    relatedGrid.innerHTML = related.map(p => renderProductCard(p)).join('');
  }
});

function selectThumb(btn, basePath) {
  btn.closest('.gallery-thumbs').querySelectorAll('button').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  const mainPicture = document.querySelector('.gallery-main picture');
  if (mainPicture) {
    mainPicture.querySelector('source').srcset = basePath + '.webp';
    mainPicture.querySelector('img').src = basePath + '.png';
  }
}
function selectColor(btn, name) {
  btn.closest('.color-swatches').querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
  btn.classList.add('active');
  const el = document.getElementById('selectedColor');
  if (el) el.textContent = name;
}
function selectSize(btn) {
  btn.closest('.size-options, div').querySelectorAll('.size-btn').forEach(s => s.classList.remove('active'));
  btn.classList.add('active');
}
function changeQty(delta) {
  const inp = document.getElementById('qtyInput');
  if (inp) inp.value = Math.max(1, Math.min(10, parseInt(inp.value) + delta));
}
