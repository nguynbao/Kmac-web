<?php
/**
 * KMAC Tech — Single Post/Product Template
 * Handles: blog posts (single.php) and WooCommerce products (via woocommerce/)
 */
get_header(); ?>

<main id="main-content">

  <?php while ( have_posts() ) : the_post(); ?>

    <article id="post-<?php the_ID(); ?>" <?php post_class('container'); ?> style="padding:40px 0 80px;">

      <!-- Breadcrumb -->
      <nav class="breadcrumb" aria-label="Breadcrumb">
        <a href="<?php echo esc_url(home_url('/')); ?>"><?php echo kmac_t('Home', 'Trang chủ'); ?></a>
        <span>›</span>
        <?php if ( get_post_type() === 'post' ) : ?>
          <a href="<?php echo esc_url(get_permalink(get_option('page_for_posts'))); ?>"><?php echo kmac_t('Blog', 'Blog'); ?></a>
          <span>›</span>
        <?php endif; ?>
        <span><?php the_title(); ?></span>
      </nav>

      <!-- H1: Title -->
      <h1 class="entry-title" style="font-size:2rem;margin:24px 0 16px;"><?php the_title(); ?></h1>

      <!-- Meta -->
      <div class="blog-meta" style="margin-bottom:32px;">
        <span>📅 <?php echo get_the_date(); ?></span>
        <span>👤 <?php the_author(); ?></span>
        <span>⏱️ <?php echo ceil(str_word_count(get_the_content()) / 200); ?> min read</span>
      </div>

      <!-- Featured Image -->
      <?php if ( has_post_thumbnail() ) : ?>
        <div style="border-radius:var(--radius-lg);overflow:hidden;margin-bottom:32px;">
          <?php the_post_thumbnail('kmac-hero', array('style' => 'width:100%;height:auto;')); ?>
        </div>
      <?php endif; ?>

      <!-- H2/H3 Content — proper heading hierarchy -->
      <div class="entry-content" style="max-width:760px;">
        <?php the_content(); ?>
      </div>

      <!-- Navigation -->
      <div style="display:flex;justify-content:space-between;margin-top:48px;padding-top:24px;border-top:1px solid var(--border);">
        <?php previous_post_link('%link', '← ' . kmac_t('Previous', 'Trước')); ?>
        <?php next_post_link('%link', kmac_t('Next', 'Tiếp theo') . ' →'); ?>
      </div>

    </article>

  <?php endwhile; ?>

</main>

<?php get_footer(); ?>
